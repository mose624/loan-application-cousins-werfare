# Cousins Welfare Loan Application System

GitHub Pages deployment package for the Cousins Welfare loan application website.

## Included
- Loan application form
- 5% monthly interest
- Two guarantors
- Coloured PDF download
- Admin dashboard
- Approve/reject loan workflow
- Admin password: `nyangau1997`

## GitHub Pages deployment
1. Create a new GitHub repository.
2. Upload `index.html` and `.nojekyll`.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Click **Save**.

## Important
This version uses browser local storage. It is a prototype and does not provide a central online database. A production version should use a secure backend/database and server-side authentication.
